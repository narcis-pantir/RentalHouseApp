package com.example.appsoftwareltds;

import android.os.Parcel;
import android.os.Parcelable;

public class ModelRoom implements Parcelable {

    String Available, Address,Available_Date,Description,Facilities,Image_ID,Number_of_Rooms,Price,Telephone,Title,Type; // these strings need be written exactly as they are in the database in order to be displayed in the home activity's recycler view


    public ModelRoom() {
    }


    protected ModelRoom(Parcel in) {
        Available = in.readString();
        Address = in.readString();
        Available_Date = in.readString();
        Description = in.readString();
        Facilities = in.readString();
        Image_ID = in.readString();
        Number_of_Rooms = in.readString();
        Price = in.readString();
        Telephone = in.readString();
        Title = in.readString();
        Type = in.readString();
    }

    public static final Creator<ModelRoom> CREATOR = new Creator<ModelRoom>() {
        @Override
        public ModelRoom createFromParcel(Parcel in) {
            return new ModelRoom(in);
        }

        @Override
        public ModelRoom[] newArray(int size) {
            return new ModelRoom[size];
        }
    };

    public String getAvailable_Date() {
        return "Available From: " +    Available_Date;
    }

    public String getDescription() {
        return "Description: " +     Description;
    }

    public String getFacilities() {
        return  "Local Amenities: " +   Facilities;
    }

    public String getNumber_of_Rooms() {
        return "Number of Rooms:" +   Number_of_Rooms;
    }

    public String getTelephone() {
        return "Telephone: " +   Telephone;
    }

    public String getTitle() {
        return "" + Title;
    }

    public String getPrice() {
        return "Price: " + Price;
    }

    public String getType() {
        return "Type of Property: " + Type;
    }

    public String getAddress() {
        return "Address: " + Address;
    }

    public String getImage_ID() {
        return Image_ID;
    }

    public String getAvailable() {
        return Available;
    }

    public void setAvailable(String available) {
        Available = available;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(Available);
        dest.writeString(Address);
        dest.writeString(Available_Date);
        dest.writeString(Description);
        dest.writeString(Facilities);
        dest.writeString(Image_ID);
        dest.writeString(Number_of_Rooms);
        dest.writeString(Price);
        dest.writeString(Telephone);
        dest.writeString(Title);
        dest.writeString(Type);
    }
}
