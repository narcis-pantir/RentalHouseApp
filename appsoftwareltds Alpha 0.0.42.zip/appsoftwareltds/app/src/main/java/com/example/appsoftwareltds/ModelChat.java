package com.example.appsoftwareltds;

import android.os.Parcel;
import android.os.Parcelable;

public class ModelChat implements Parcelable{


        String UserName;
        String Chat;
        String Image_ID;
        String ID;


        public ModelChat(){}

        protected ModelChat(Parcel in) {

            UserName = in.readString();

            Chat = in.readString();

            Image_ID = in.readString();

            ID = in.readString();


        }

        public static final Creator<ModelChat> CREATOR = new Creator<ModelChat>() {
            @Override
            public ModelChat createFromParcel(Parcel in) {
                return new ModelChat(in);
            }

            @Override
            public ModelChat[] newArray(int size) {
                return new ModelChat[size];
            }
        };



        public String getID() {
            return ID;
        }

        public void setID(String ID) {
            this.ID = ID;
        }

        public String getUserName() {
            return  UserName;
        }

        public String getChat() {
            return  Chat;
        }


        public String getImage_ID() {
            return Image_ID;
        }

        // these strings need be written exactly as they are in the database in order to be displayed in the home activity's recycler view



        @Override
        public int describeContents() {
            return 0;
        }


        @Override
        public void writeToParcel(Parcel dest, int flags) {

            dest.writeString(UserName);

            dest.writeString(Chat);

            dest.writeString(Image_ID);

            dest.writeString(ID);

        }


    }





