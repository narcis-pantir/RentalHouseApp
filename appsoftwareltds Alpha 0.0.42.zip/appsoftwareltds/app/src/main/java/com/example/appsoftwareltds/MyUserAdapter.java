
package com.example.appsoftwareltds;

        import android.content.Context;
        import android.content.Intent;
        import android.net.Uri;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.TextView;

        import androidx.annotation.NonNull;
        import androidx.recyclerview.widget.RecyclerView;

        import com.bumptech.glide.Glide;
        import com.google.android.gms.tasks.OnFailureListener;
        import com.google.android.gms.tasks.OnSuccessListener;
        import com.google.android.gms.tasks.Task;
        import com.google.android.material.snackbar.Snackbar;
        import com.google.firebase.database.DatabaseReference;
        import com.google.firebase.database.FirebaseDatabase;
        import com.google.firebase.database.Query;
        import com.google.firebase.storage.FirebaseStorage;
        import com.google.firebase.storage.StorageReference;
        import com.google.firebase.storage.UploadTask;
        import com.squareup.picasso.Picasso;

        import android.widget.ImageView;
        import java.util.ArrayList;
        import java.util.HashMap;


public class MyUserAdapter extends RecyclerView.Adapter<MyUserAdapter.MyViewHolder> {

    StorageReference storageReference = FirebaseStorage.getInstance().getReference();
    public Uri imageURL;
    ArrayList<ModelUser> uList;
    Context context;
    public String ImageID;

    public MyUserAdapter (Context context, ArrayList<ModelUser> mList){
        this.uList = mList;
        this.context = context;

    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.user_card, parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        ModelUser model = uList.get(position);
        String UserID = model.getID();
        StorageReference UserPic = storageReference.child("users/"+UserID);   // NOT WORKING!!

        UserPic.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                ImageID = uri.toString();
            }
        });


      //  String userImage = ;
      //  ModelUser model = uList.get(position);
        holder.FName.setText(model.getFirst_Name());
        holder.LName.setText(model.getLast_Name());
        holder.Type.setText(model.getAccount_Type());
        holder.Address.setText(model.getAddress());
        holder.UserPicture.setVisibility(View.VISIBLE);

       try {
            Glide.with(context).load(ImageID).into(holder.UserPicture);
        } catch (Exception e) {}

    }


    @Override
    public int getItemCount() {
        return uList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        ImageView UserPicture;
        TextView FName,LName, Type, Address;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            FName = itemView.findViewById(R.id.UserFName_display);
            LName = itemView.findViewById(R.id.UserLName_display);
            Type  = itemView.findViewById(R.id.UserType_display);
            Address  = itemView.findViewById(R.id.UAdress_display);
            UserPicture = itemView.findViewById(R.id.UserImageView);



        }
    }
}
