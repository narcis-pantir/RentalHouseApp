package com.example.appsoftwareltds;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;

public class SingleRoom extends AppCompatActivity {

    private Button UserChatBtn, UserProfileBtn,BackBtn,MakeUnavailable,MakeAvailable;
    private ImageView singlePostImg;
    private TextView SinglePostTitle, SinglePostType, SinglePostPrice, SinglePostLocation,SinglePostAvailable,SinglePostNOR,SinglePostPhone,SinglePostLA,SinglePostDescription;
    private DatabaseReference mDatabase, aDatabase;
    private Query query;

//this activity will be presented to the user when he clicks on an individual room post in 'HomeActivity'

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_room);

        ModelRoom Room = getIntent().getParcelableExtra("property");

        MakeUnavailable = findViewById(R.id.UnavailableBtn);
        MakeAvailable = findViewById(R.id.AvailableBtn);
        BackBtn = findViewById(R.id.BackButton2);
        UserChatBtn = findViewById(R.id.ChatRenter);
        UserProfileBtn = findViewById(R.id.VisitProfile);

        singlePostImg = findViewById(R.id.post_view_img);
        SinglePostTitle = findViewById(R.id.post_view_title);
        SinglePostType = findViewById(R.id.post_view_type);
        SinglePostPrice = findViewById(R.id.post_view_price);
        SinglePostLocation = findViewById(R.id.post_view_address);
        SinglePostAvailable = findViewById(R.id.post_view_available);
        SinglePostNOR = findViewById(R.id.post_view_nor);
        SinglePostPhone = findViewById(R.id.post_view_phone);
        SinglePostLA = findViewById(R.id.post_view_la);
        SinglePostDescription = findViewById(R.id.post_view_description);

        Picasso.get().load(Room.getImage_ID()).fit().into(singlePostImg);
        SinglePostTitle.setText(Room.getTitle());
        SinglePostType.setText(Room.getType());
        SinglePostPrice.setText(Room.getPrice());
        SinglePostLocation.setText(Room.getAddress());
        SinglePostAvailable.setText(Room.getAvailable_Date());
        SinglePostNOR.setText(Room.getNumber_of_Rooms());
        SinglePostPhone.setText(Room.getTelephone());
        SinglePostLA.setText(Room.getFacilities());
        SinglePostDescription.setText(Room.getDescription());



        query = FirebaseDatabase.getInstance().getReference().child("User_Properties").child("Posted_Properties").orderByChild("Image_ID").equalTo(Room.getImage_ID());

        final String[] room = new String[1];
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dss : snapshot.getChildren()) {
                    room[0] = dss.getKey();
                }
              // Toast.makeText(SingleRoom.this, room[0], Toast.LENGTH_LONG).show();
                aDatabase = FirebaseDatabase.getInstance().getReference().child("User_Properties").child("Posted_Properties").child(room[0]);
            }



            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });




        if (getIntent().getBooleanExtra("Availability", true)){
            MakeAvailable.setVisibility(View.VISIBLE);
            MakeUnavailable.setVisibility(View.VISIBLE);
            UserChatBtn.setVisibility(View.INVISIBLE);
            UserProfileBtn.setVisibility(View.INVISIBLE);
        } else {MakeAvailable.setVisibility(View.INVISIBLE);
        MakeUnavailable.setVisibility(View.INVISIBLE);
        UserChatBtn.setVisibility(View.VISIBLE);
        UserProfileBtn.setVisibility(View.VISIBLE);}

        UserChatBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SingleRoom.this, Chat.class));
            }
        });



      //  Toast.makeText(SingleRoom.this, Room.getAvailable(), Toast.LENGTH_LONG).show();

        MakeAvailable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                HashMap<String, Object> map = new HashMap();
                if (Room.getAvailable().compareTo("false") == 0) {
                    map.put("Available", ((Object)"true")); }

                Toast.makeText(SingleRoom.this, "Room marked as Available", Toast.LENGTH_LONG).show();
                aDatabase.updateChildren(map);
                startActivity(new Intent(SingleRoom.this, ViewMyListings.class));
            }
        });

        MakeUnavailable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                HashMap<String, Object> map2 = new HashMap();
                if (Room.getAvailable().compareTo("true") == 0) {
                    map2.put("Available", ((Object)"false"));}

                Toast.makeText(SingleRoom.this, "Room marked as Unavailable", Toast.LENGTH_LONG).show();
                aDatabase.updateChildren(map2);
                startActivity(new Intent(SingleRoom.this, ViewMyListings.class));
            }
        });


        BackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SingleRoom.this, HomeActivity.class));
            }
        });


        mDatabase= FirebaseDatabase.getInstance().getReference().child("User_Properties").child("Posted_Properties");
        mDatabase.addValueEventListener(new ValueEventListener() {

        @Override
        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
            String post_address= (String) dataSnapshot.child("Address").getValue();
            String post_available= (String) dataSnapshot.child("Available_Date").getValue();

        //SinglePostLocation.setText(Title.getTitle()); ????



        }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }

        });
    }







}