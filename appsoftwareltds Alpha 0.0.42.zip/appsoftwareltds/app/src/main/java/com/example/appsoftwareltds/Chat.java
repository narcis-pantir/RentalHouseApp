package com.example.appsoftwareltds;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

public class Chat extends AppCompatActivity {

    private EditText AddComment;
    private Button Back,Send;
    private MyChatAdapter ChatAdapter;
    private ArrayList<ModelChat> ChatList;
    FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    DatabaseReference ChatRoot, root = firebaseDatabase.getReference().child("Chats");;
    DatabaseReference databaseReference;
    FirebaseAuth mAuth = FirebaseAuth.getInstance();
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);



        recyclerView = findViewById(R.id.chat_recycler);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        ChatList = new ArrayList<>();
        ChatAdapter = new MyChatAdapter(this, ChatList);

        recyclerView.setAdapter(ChatAdapter);

        AddComment = findViewById(R.id.Add_Comm);


        Send = findViewById(R.id.send_chat);
        Back = findViewById(R.id.BackButtonC);
        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Chat.this, HomeActivity.class));
            }
        });

        Send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseDatabase ForumData = FirebaseDatabase.getInstance();
                ChatRoot = ForumData.getReference().child("Chats");


                databaseReference = firebaseDatabase.getReference("User_Data").child("Details");


                Query UserNameQuery = databaseReference.orderByChild("ID").equalTo(mAuth.getCurrentUser().getUid());
                UserNameQuery.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                            String Name = " " + dataSnapshot1.child("First_Name").getValue() + " " + dataSnapshot1.child("Last_Name").getValue();
                            String User_Said = AddComment.getText().toString();

                            HashMap<String, String> PostMap = new HashMap<>();

                            PostMap.put("UserID", mAuth.getCurrentUser().getUid());
                            PostMap.put("Chat", User_Said);;
                            PostMap.put("UserName", Name);


                            ChatRoot.push().setValue(PostMap);

                            ChatAdapter.notifyDataSetChanged();


                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });


            }
        });




                // this will display comments under each post that are also SPECIFIC to that post
        Query Comment_ID_Query = root.orderByChild("PostID"); //.equalTo(PostID...); *****unfinished + no inbox
        Comment_ID_Query.addValueEventListener(new ValueEventListener() {
           @Override
           public void onDataChange(@NonNull DataSnapshot snapshot) {
              for (DataSnapshot dataSnapshot : snapshot.getChildren()) {

                  ModelChat model = dataSnapshot.getValue(ModelChat.class);
                  ChatList.add(model);

                    ChatAdapter.notifyDataSetChanged();
               }
           }

           @Override
          public void onCancelled(@NonNull DatabaseError error) {

            }
        });











    }
}