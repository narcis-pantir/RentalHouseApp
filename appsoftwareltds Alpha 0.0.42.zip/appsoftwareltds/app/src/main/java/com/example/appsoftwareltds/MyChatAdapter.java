package com.example.appsoftwareltds;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class MyChatAdapter extends RecyclerView.Adapter<MyChatAdapter.MyChatViewHolder> {


        ArrayList<ModelChat> cList;
        Context CContext;



        public MyChatAdapter (Context CContext, ArrayList<ModelChat> cList){
            this.cList = cList;
            this.CContext = CContext;


        }

        @NonNull
        @Override
        public MyChatAdapter.MyChatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(CContext).inflate(R.layout.chat_card, parent, false);
            return new MyChatAdapter.MyChatViewHolder(v);


        }



        @Override
        public void onBindViewHolder(@NonNull MyChatAdapter.MyChatViewHolder holder, int position) {



            ModelChat model = cList.get(position);
            String PostImage = cList.get(position).getImage_ID();
            holder.ChatName.setText(model.getUserName());
            holder.ChatSaid.setText(model.getChat());
            holder.ChatPic.setVisibility(View.VISIBLE);
            try {
                Glide.with(CContext).load(PostImage).into(holder.ChatPic);
            } catch (Exception e) {}


        }


        @Override
        public int getItemCount() {
            return cList.size();
        }


    public static class MyChatViewHolder extends RecyclerView.ViewHolder{


            ImageView ChatPic;
            TextView ChatName,ChatSaid;

            public MyChatViewHolder(@NonNull View itemView) {
                super(itemView);

                ChatName = itemView.findViewById(R.id.chat_name);
                ChatSaid = itemView.findViewById(R.id.chat1);
                ChatPic = itemView.findViewById(R.id.ChatImageView);


            }



        }



    }
