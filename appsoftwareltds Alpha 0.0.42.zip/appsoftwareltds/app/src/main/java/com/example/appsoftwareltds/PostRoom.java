package com.example.appsoftwareltds;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.annotations.NotNull;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

public class PostRoom extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private Button Back, PostRoom, PostPicture;
    public Uri imageURL;
    private FirebaseStorage storage;
    private StorageReference storageReference;
    public String ImageID;




    Switch PaySwitch, Smoke_Switch, Disabled_Switch, Fully_Furnished_Switch, Internet_Switch, Pets_Switch, Bus_Switch, Train_Switch;
    Spinner PropertyType_spinner;
    Spinner NumberOfRooms_spinner;
    EditText InputRoomTitle, InputRoomLocation, InputRoomDate, InputRoomPrice, InputRoomDescription,InputRoomTelephone;
    ImageView PictureUpload;


    FirebaseAuth mAuth; //FOR USER DETAILS
    private FirebaseDatabase RoomData = FirebaseDatabase.getInstance();
    private DatabaseReference RoomRoot = RoomData.getReference().child("User_Properties").child("Posted_Properties");





    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==1 && resultCode==RESULT_OK && data != null && data.getData() != null){
            imageURL = data.getData();
            PictureUpload.setImageURI(imageURL);
            uploadPicture();
            ImageID = imageURL.toString();

        }
    }

    public void uploadPicture() {


        final ProgressDialog pd = new ProgressDialog(this);
        pd.setTitle("Uploading Image...");
        pd.show();

        final String randomKey = UUID.randomUUID().toString();
       StorageReference LocRef = storageReference.child("images/" + randomKey);



       LocRef.putFile(imageURL).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>(){
           @Override
                   public void onSuccess(UploadTask.TaskSnapshot taskSnapshot){
              // Uri downloadUrl = taskSnapshot.getDownloadUrl();




               Task<Uri> result = taskSnapshot.getStorage().getDownloadUrl(); // this task will retrieve the image url
               result.addOnSuccessListener(new OnSuccessListener<Uri>() {
                   @Override
                   public void onSuccess(Uri uri) {
                       String imageUrl = uri.toString();
                       ImageID = imageUrl; // once the url is retrieved it will be uploaded to firebase as a string (and retrieved later in the home activity)
                   }
               });


               pd.dismiss();
               Snackbar.make(findViewById(android.R.id.content),"Image Uploaded",Snackbar.LENGTH_SHORT).show();



           }
        })

               .addOnFailureListener(new OnFailureListener(){
                   @Override
                   public void onFailure(@NonNull @NotNull Exception exception){
                       pd.dismiss();
                       Toast.makeText(getApplicationContext(),"Error: Upload Failed",Toast.LENGTH_LONG).show();
                   }
               })

           .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>(){
               @Override
            public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot){
                   double progressPercent = (100.00 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                   pd.setMessage("Percentage: " + (int) progressPercent + "%");
               } // this will show the user the current progress percentage of the uploading file based on file's size


        });



    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_room);

        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();
        PictureUpload = findViewById(R.id. HomePicture);
        PostPicture = findViewById(R.id.PicturePostBtn);
        PostRoom = findViewById(R.id.PostRoomBtn);
        Back = findViewById(R.id.BackButton1);


        Back.setOnClickListener(new View.OnClickListener() {     // The back button will take the user back to home activity
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PostRoom.this, HomeActivity.class));
            }
        });

        PostPicture.setOnClickListener(new View.OnClickListener(){  //  theses button will upload pictures on the firebase storage
            @Override
            public void onClick(View v){
            choosePicture();
            }

            private void choosePicture() {
                Intent pictureIntent = new Intent();
                pictureIntent.setType("image/*");

                pictureIntent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(pictureIntent,1 );
            }
        });





        //Code for Spinners: ~ property type and number of rooms:
        PropertyType_spinner = findViewById(R.id.property_type_spinner);
        NumberOfRooms_spinner = findViewById(R.id.rooms_number_spinner);

        ArrayAdapter PType = ArrayAdapter.createFromResource(PostRoom.this,R.array.PostPropertyType, android.R.layout.simple_spinner_item);
        PropertyType_spinner.setAdapter(PType);
        PropertyType_spinner.setOnItemSelectedListener(this);

        ArrayAdapter RNumber = ArrayAdapter.createFromResource(PostRoom.this,R.array.PostRoomRooms, android.R.layout.simple_spinner_item);
        NumberOfRooms_spinner.setAdapter(RNumber);
        NumberOfRooms_spinner.setOnItemSelectedListener(this);

        //Code for Spinners: ~ ends here.

        PaySwitch = (Switch)findViewById(R.id.PaymentSwitch); //Week/month payment switch
        Smoke_Switch = (Switch)findViewById(R.id.SmokeSwitch);             //facilities switches,    all mapped to switch views from activity_post_room.xml
        Disabled_Switch = (Switch)findViewById(R.id.DisabledSwitch);
        Fully_Furnished_Switch = (Switch)findViewById(R.id.FullyFurnishedSwitch);
        Internet_Switch = (Switch)findViewById(R.id.InternetSwitch);
        Pets_Switch = (Switch)findViewById(R.id.PetsSwitch);
        Bus_Switch = (Switch)findViewById(R.id.BusSwitch);
        Train_Switch = (Switch)findViewById(R.id.TrainSwitch);





        PostRoom.setOnClickListener(new View.OnClickListener() {        // room posting button
            @Override
            public void onClick(View v) {

                mAuth = FirebaseAuth.getInstance();

                InputRoomTitle = (findViewById(R.id.PostRoomTitle));
                InputRoomLocation = (findViewById(R.id.PostRoomAdress));
                InputRoomDate = (findViewById(R.id.PostRoomDate));
                InputRoomPrice = (findViewById(R.id.PostRoomPrice));
                InputRoomDescription = (findViewById(R.id.PostRoomDescription));
                InputRoomTelephone = (findViewById(R.id.PostRoomPhone));



                // applying condition for fields NOT to be empty:
                if (!TextUtils.isEmpty(InputRoomTitle.getText().toString())&& !TextUtils.isEmpty(InputRoomLocation.getText().toString())
                && !TextUtils.isEmpty(InputRoomPrice.getText().toString()) && !TextUtils.isEmpty(InputRoomDescription.getText().toString())
                && !TextUtils.isEmpty(InputRoomDate.getText().toString())  ){




                //saving USER DATA start ---------------------------------------------

                String RoomTitle = InputRoomTitle.getText().toString();
                String RoomLocation = InputRoomLocation.getText().toString();
                String RoomDate = InputRoomDate.getText().toString();
                String RoomPrice = InputRoomPrice.getText().toString();
                String PerWM, Fa_Smoke, Fa_Disabled, Fa_Furn, Fa_Internet, Fa_Pet, Fa_Bus, Fa_Train,Spacer;
                Spacer = "/";


                if (PaySwitch.isChecked())          //this if statement will get the text from the payment switch itself, meaning:
                    PerWM = PaySwitch.getTextOn().toString(); //if it's ON the value of the PerWM variable will be "Week"
                else
                    PerWM = PaySwitch.getTextOff().toString(); //if it's Off the value of the PerWM variable will be "Month"

                // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                if (Smoke_Switch.isChecked())
                    Fa_Smoke = "Smoker Friendly" + Spacer;
                else
                    Fa_Smoke = "";
                // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                if (Disabled_Switch.isChecked())
                    Fa_Disabled = "Disability Friendly or Adjustable";
                else
                    Fa_Disabled = "";
                // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                if (Fully_Furnished_Switch.isChecked())
                    Fa_Furn = "Fully Furnished" + Spacer;
                else
                    Fa_Furn = "";
                // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                if (Internet_Switch.isChecked())
                    Fa_Internet = "Internet on the premises" + Spacer;
                else
                    Fa_Internet = "";
                // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                if (Pets_Switch.isChecked())
                    Fa_Pet = "Pets Allowed" + Spacer;
                else
                    Fa_Pet = "";

                // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                if (Bus_Switch.isChecked())
                    Fa_Bus = "Close to Bus Station" + Spacer;
                else
                    Fa_Bus = "";

                // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                if (Train_Switch.isChecked())
                    Fa_Train = "Close to Train Station";
                else
                    Fa_Train = "";



                String RoomDescription = InputRoomDescription.getText().toString();
                String RoomTelephone = InputRoomTelephone.getText().toString();
                if (TextUtils.isEmpty(InputRoomTelephone.getText().toString())) {RoomTelephone = ("Not Specified");}
                String PropertyType = PropertyType_spinner.getSelectedItem().toString();
                String NumberOfRooms = NumberOfRooms_spinner.getSelectedItem().toString();




                HashMap<String , String> RoomMap = new HashMap<>();


                RoomMap.put("UserID" , mAuth.getCurrentUser().getUid());
                RoomMap.put("Title" , RoomTitle);
                RoomMap.put("Address" , RoomLocation);
                RoomMap.put("Available_Date" , RoomDate);
                RoomMap.put("Price" , RoomPrice + "£ per " + PerWM);
                RoomMap.put("Description" , RoomDescription);
                RoomMap.put("Telephone" , RoomTelephone);
                RoomMap.put("Type" , PropertyType);
                RoomMap.put("Number_of_Rooms" , NumberOfRooms);
                RoomMap.put("Facilities", Fa_Smoke + " " + Fa_Disabled + " " + Fa_Furn + " " + Fa_Internet + " " + Fa_Pet + " " + Fa_Bus + " " + Fa_Train);
                RoomMap.put("Image_ID", ImageID);
                RoomMap.put("Available", "true");


                RoomRoot.push().setValue(RoomMap);

                Toast.makeText(PostRoom.this, "Property Posted", Toast.LENGTH_LONG).show();
                startActivity(new Intent(PostRoom.this, HomeActivity.class));



            }else {Toast.makeText(PostRoom.this, "One or more fields are empty", Toast.LENGTH_LONG).show();} }
        }); // room posting button END



    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}