package com.example.appsoftwareltds;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;



public class AccountProfile extends AppCompatActivity {

    FirebaseUser firebaseUser;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    TextView nam, email, type;
    private Button goBack, logout, resetPw;
    Button changeProfileImage;
    FirebaseAuth mAuth;
    ImageView profileImage;
    StorageReference storageReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_profile);
        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("User_Data").child("Details");
        mAuth = FirebaseAuth.getInstance();
        email =  findViewById(R.id.profile_email);
        nam = findViewById(R.id.profile_name);
        type = findViewById(R.id.profile_type);
        goBack =findViewById(R.id.goBack);
        logout =findViewById(R.id.logout2nd);
        resetPw = findViewById(R.id.resetPasswordLocal);
        profileImage = findViewById(R.id.profileImage);
        changeProfileImage = findViewById(R.id.changeProfile);
        storageReference = FirebaseStorage.getInstance().getReference();
        StorageReference profileRef = storageReference.child("users/"+mAuth.getCurrentUser().getUid());


        profileRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Picasso.get().load(uri).into(profileImage);
            } // picasso will load the URL of the image into the picture view holder in order for the user to view his picture when he has changed it
        });


        logout.setOnClickListener(new View.OnClickListener() { // the log out button will log out the user and bring him back to the log in activity (Main Activity)
            @Override
            public void onClick(View view) {
                mAuth = FirebaseAuth.getInstance();
                mAuth.signOut();
                startActivity(new Intent(AccountProfile.this,MainActivity.class));
                Toast.makeText(AccountProfile.this, "Log-out Successful", Toast.LENGTH_LONG).show();
            }
        });

        goBack.setOnClickListener(new View.OnClickListener() {     // The back button will take the user back to home activity
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AccountProfile.this, HomeActivity.class));
            }
        });


        resetPw.setOnClickListener(new View.OnClickListener() { // reset password will work the same as the forgot password on main activity and will also log out the user
            @Override
            public void onClick(View view) {

                EditText resetMail = new EditText(view.getContext());
                AlertDialog.Builder passwordResetDialog = new AlertDialog.Builder(view.getContext());
                passwordResetDialog.setTitle("You want to reset your Password?");
                passwordResetDialog.setMessage("Please enter your email to receiver the reset password link");
                passwordResetDialog.setView(resetMail);

                passwordResetDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String mail = resetMail.getText().toString();
                        mAuth.sendPasswordResetEmail(mail).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                mAuth = FirebaseAuth.getInstance();
                                mAuth.signOut();
                                Toast.makeText(AccountProfile.this, "Reset link sent to your email", Toast.LENGTH_SHORT).show();
                                Toast.makeText(AccountProfile.this, "Please Log In Again", Toast.LENGTH_LONG).show();
                                Intent intent=new Intent(AccountProfile.this,HomeActivity.class);
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(AccountProfile.this, "Error! reset link not sent" + e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });

                    }
                });

                passwordResetDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });

                passwordResetDialog.create().show();

            }
        });





        Query query = databaseReference.orderByChild("ID").equalTo(firebaseUser.getUid());
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                    String name = " " + dataSnapshot1.child("First_Name").getValue() + " " + dataSnapshot1.child("Last_Name").getValue();
                    String emailL = " " + dataSnapshot1.child("Email").getValue();
                    String type1 = " " + dataSnapshot1.child("Account_Type").getValue();
                    nam.setText(name);
                    email.setText(emailL);
                    type.setText(type1);
                }       //this will read the user details in order to display them on the page: Full Name, Email, Account Type
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        changeProfileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //open gallery

                Intent openGalleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(openGalleryIntent,1000);

            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1000){
            if(resultCode == Activity.RESULT_OK){
                Uri imageUri = data.getData();


               // profileImage.setImageURI(imageUri);
                
                uploadImageToFirebase(imageUri);
            }
        }
    }

    private void uploadImageToFirebase(Uri imageUri) {
        //upload image to firebase storage

        final StorageReference fileRef = storageReference.child("users/"+mAuth.getCurrentUser().getUid());
        fileRef.putFile(imageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                fileRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        Picasso.get().load(uri).into(profileImage);

                    }
                });

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(AccountProfile.this, "Failed To Upload the Image", Toast.LENGTH_SHORT).show();
            }
        });

    }
}