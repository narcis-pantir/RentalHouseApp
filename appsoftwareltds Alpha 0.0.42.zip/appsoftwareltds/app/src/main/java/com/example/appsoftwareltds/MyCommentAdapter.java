package com.example.appsoftwareltds;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class MyCommentAdapter extends RecyclerView.Adapter<MyCommentAdapter.MyCommentViewHolder> {


    ArrayList<ModelComment> cList;
    Context CContext;



    public MyCommentAdapter (Context CContext, ArrayList<ModelComment> cList){
        this.cList = cList;
        this.CContext = CContext;


    }

    @NonNull
    @Override
    public MyCommentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(CContext).inflate(R.layout.comment_card, parent, false);
        return new MyCommentAdapter.MyCommentViewHolder(v);


    }



    @Override
    public void onBindViewHolder(@NonNull MyCommentViewHolder holder, int position) {



        ModelComment model = cList.get(position);
        String PostImage = cList.get(position).getImage_ID();
        holder.CName.setText(model.getUserName());
        holder.CComment.setText(model.getComment());
        holder.CommentPic.setVisibility(View.VISIBLE);
        try {
            Glide.with(CContext).load(PostImage).into(holder.CommentPic);
        } catch (Exception e) {}


    }


    @Override
    public int getItemCount() {
        return cList.size();
    }

    public static class MyCommentViewHolder extends RecyclerView.ViewHolder{


        ImageView CommentPic;
        TextView CName,CComment;

        public MyCommentViewHolder(@NonNull View itemView) {
            super(itemView);

            CName = itemView.findViewById(R.id.UserName_display);
            CComment = itemView.findViewById(R.id.Comment_display);
            CommentPic = itemView.findViewById(R.id.UserImageView);


        }



    }


}
