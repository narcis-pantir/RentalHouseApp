package com.example.appsoftwareltds;


import android.os.Parcel;
import android.os.Parcelable;

public class ModelComment implements Parcelable {
    String UserName;
    String Comment;
    String Image_ID;
    String ID;
    String PostID;

    public ModelComment(){}

    protected ModelComment(Parcel in) {

        UserName = in.readString();

        Comment = in.readString();

        Image_ID = in.readString();

        ID = in.readString();

        PostID = in.readString();

    }

    public static final Creator<ModelComment> CREATOR = new Creator<ModelComment>() {
        @Override
        public ModelComment createFromParcel(Parcel in) {
            return new ModelComment(in);
        }

        @Override
        public ModelComment[] newArray(int size) {
            return new ModelComment[size];
        }
    };


    public String getPostID() {
        return PostID;
    }

    public void setPostID(String PostID) {
        PostID = PostID;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getUserName() {
        return  UserName;
    }

    public String getComment() {
        return  Comment;
    }


    public String getImage_ID() {
        return Image_ID;
    }

     // these strings need be written exactly as they are in the database in order to be displayed in the home activity's recycler view



    @Override
    public int describeContents() {
        return 0;
    }


    @Override
    public void writeToParcel(Parcel dest, int flags) {

        dest.writeString(UserName);

        dest.writeString(Comment);

        dest.writeString(Image_ID);

        dest.writeString(ID);
        dest.writeString(PostID);
    }
    

}

