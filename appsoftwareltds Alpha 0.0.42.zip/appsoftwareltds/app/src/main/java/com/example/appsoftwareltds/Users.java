package com.example.appsoftwareltds;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;


public class Users extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {



    private DrawerLayout drawer;
    private Toolbar toolbar;
    private Button Rooms, Forum;
    private RecyclerView recyclerView;
    FirebaseDatabase db = FirebaseDatabase.getInstance();
    private DatabaseReference root = db.getReference().child("User_Data").child("Details");
    private MyUserAdapter adapter;
    private ArrayList<ModelUser> mlist;
    FirebaseUser currentUser ;

    FirebaseAuth mAuth = FirebaseAuth.getInstance();




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users);
        Forum = findViewById(R.id.Forum);
        Forum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Users.this,Forum.class));
            }
        });

        Rooms = findViewById(R.id.Rooms);
        Rooms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Users.this,HomeActivity.class));
            }
        });

        toolbar = findViewById(R.id.toolbar1);
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        //create variable
        NavigationView navigationView = findViewById(R.id.nav_view) ;
        navigationView.setNavigationItemSelectedListener(this);


        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();



        recyclerView = findViewById(R.id.UserRecycler);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        mlist = new ArrayList<>();

        adapter = new MyUserAdapter(this, mlist);

        recyclerView.setAdapter(adapter);

        root.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                    ModelUser model = dataSnapshot.getValue(ModelUser.class);
                    mlist.add(model);       // this shows the current registered users list

                }
                adapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        updateNavHeader();
    }



    @Override
    public boolean onNavigationItemSelected (@NonNull @NotNull MenuItem item) {

        switch (item.getItemId()) {  //drawer menu buttons
            case R.id.nav_account:   // view current user profile button -> takes user to AccountProfile activity
                startActivity(new Intent(Users.this,AccountProfile.class));
                break; //if we don't put break will execute what is bellow it

            case R.id.nav_logout:  // log out button
                //getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new Logout()).commit();
                mAuth = FirebaseAuth.getInstance();
                mAuth.signOut();
                startActivity(new Intent(Users.this,MainActivity.class));
                Toast.makeText(Users.this, "Logout Successful", Toast.LENGTH_LONG).show();
                break;

            case R.id.nav_rent:  // post new property button
                startActivity(new Intent(Users.this,PostRoom.class));
                // code here
                break;

            case R.id.nav_viewListing:// view user's posted property button
                startActivity(new Intent(Users.this,ViewMyListings.class));
                break;
        }

        drawer.closeDrawer(GravityCompat.START);
        return super.onContextItemSelected(item);
    }


    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)){
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
        super.onBackPressed();
    }



    public void updateNavHeader() { // this class will display the registered user's email in the drawer menu

        NavigationView navigationView = findViewById(R.id.nav_view) ;
        View headerView = navigationView.getHeaderView(0);
        TextView navUserMail = headerView.findViewById(R.id.nav_user_email);
        currentUser = mAuth.getCurrentUser();
        if (currentUser.getEmail() != null){navUserMail.setText(currentUser.getEmail());}


    }





}
