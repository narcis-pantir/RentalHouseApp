package com.example.appsoftwareltds;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.annotations.NotNull;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;
import java.util.UUID;

public class PostForum extends AppCompatActivity {

    private EditText Forum_Title, Forum_Description;
    private ImageView Forum_Image;
    private Button ForumPost, Forum_PicBtn, Back_Button;
    public Uri ForumURL;
    public String ForumImageID, postID;
    private StorageReference storageReference;
    private FirebaseStorage storage;


    FirebaseAuth mAuth;


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            ForumURL = data.getData();
            Forum_Image.setImageURI(ForumURL);
            uploadPicture();
            ForumImageID = ForumURL.toString();

        }
    }

    public void uploadPicture() {


        final ProgressDialog pd = new ProgressDialog(this);
        pd.setTitle("Uploading Image...");
        pd.show();

        final String randomKey = UUID.randomUUID().toString();
        StorageReference LocRef = storageReference.child("Forum_Images/" + randomKey);


        LocRef.putFile(ForumURL).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                // Uri downloadUrl = taskSnapshot.getDownloadUrl();


                Task<Uri> result = taskSnapshot.getStorage().getDownloadUrl(); // this task will retrieve the image url
                result.addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        String imageUrl = uri.toString();
                        ForumImageID = imageUrl; // once the url is retrieved it will be uploaded to firebase as a string
                    }                               //and retrieved later in the forum activity as individual image views
                });


                pd.dismiss();
                Snackbar.make(findViewById(android.R.id.content), "Image Uploaded", Snackbar.LENGTH_SHORT).show();


            }
        })

                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull @NotNull Exception exception) {
                        pd.dismiss();
                        Toast.makeText(getApplicationContext(), "Error: Upload Failed", Toast.LENGTH_LONG).show();
                    }
                })

                .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                    @Override       // this will show the user the current progress percentage of the uploading file based on file's size
                    public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                        double progressPercent = (100.00 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                        pd.setMessage("Percentage: " + (int) progressPercent + "%");
                    }


                });


    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_forum);

        mAuth = FirebaseAuth.getInstance();
        FirebaseDatabase ForumData = FirebaseDatabase.getInstance();
        DatabaseReference RoomRoot = ForumData.getReference().child("Forums"); //USER DATA





        postID = UUID.randomUUID().toString();
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();
        Back_Button = findViewById(R.id.BackButton3);
        Forum_PicBtn = findViewById(R.id.ForumPicBtn);
        Forum_Title = findViewById(R.id.ForumTitle);
        Forum_Description = findViewById(R.id.ForumDescription);
        Forum_Image = findViewById(R.id.ForumImage);
        ForumPost = findViewById(R.id.ForumUpload);

        Back_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PostForum.this, Forum.class));
            }
        });

        Forum_PicBtn.setOnClickListener(new View.OnClickListener() {  //  theses button will upload pictures on the firebase storage
            @Override
            public void onClick(View v) {
                choosePicture();
            }

            private void choosePicture() {
                Intent pictureIntent = new Intent();
                pictureIntent.setType("image/*");

                pictureIntent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(pictureIntent, 1);
            }
        });


        ForumPost.setOnClickListener(new View.OnClickListener() {        // room posting button
            @Override
            public void onClick(View v) {
                if (!TextUtils.isEmpty(Forum_Title.getText().toString())&& !TextUtils.isEmpty(Forum_Description.getText().toString())  ) {

                    String ForumT = Forum_Title.getText().toString();
                    String ForumD = Forum_Description.getText().toString();


                    HashMap<String, String> ForumMap = new HashMap<>();


                    ForumMap.put("UserID", mAuth.getCurrentUser().getUid());
                    ForumMap.put("Title", ForumT);
                    ForumMap.put("Description", ForumD);
                    ForumMap.put("Image_ID", ForumImageID);
                    ForumMap.put("Post_ID", postID);


                    RoomRoot.push().

                            setValue(ForumMap);

                    Toast.makeText(PostForum.this, "Blog Post Posted", Toast.LENGTH_LONG).

                            show();     // entered data will be stored in Firebase

                    ;

                    startActivity(new Intent(PostForum.this, Forum.class));
                } else {Toast.makeText(PostForum.this, "One or more fields are empty", Toast.LENGTH_LONG).show();}
            }
        });
    }
}
