package com.example.appsoftwareltds;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class MyForumAdapter extends RecyclerView.Adapter<MyForumAdapter.MyForumViewHolder> {



        ArrayList<ModelForum> fList;
        Context FContext;
        MyForumViewHolder.OnPostClick PostListener;


        public MyForumAdapter (Context FContext, ArrayList<ModelForum> fList, MyForumViewHolder.OnPostClick f_listener){
            this.fList = fList;
            this.FContext = FContext;
            PostListener = f_listener;

        }

    @NonNull
    @Override
    public MyForumAdapter.MyForumViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(FContext).inflate(R.layout.forum_card, parent, false);
        return new MyForumAdapter.MyForumViewHolder(v, PostListener);


    }




        @Override
        public void onBindViewHolder(@NonNull MyForumViewHolder holder, int position) {



            ModelForum model = fList.get(position);
            String PostImage = fList.get(position).getImage_ID();
            holder.FTitle.setText(model.getTitle());
            holder.FDescription.setText(model.getDescription());
            holder.ForumPostPicture.setVisibility(View.VISIBLE);
            try {
                Glide.with(FContext).load(PostImage).into(holder.ForumPostPicture);
            } catch (Exception e) {}


        }


        @Override
        public int getItemCount() {
            return fList.size();
        }

        public static class MyForumViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{


            OnPostClick PostListener;


            ImageView ForumPostPicture;
            TextView FTitle,FDescription;

            public MyForumViewHolder(@NonNull View itemView, OnPostClick f_listener) {
                super(itemView);

                FTitle = itemView.findViewById(R.id.TopicTitle);
                FDescription = itemView.findViewById(R.id.Description_display);
                ForumPostPicture = itemView.findViewById(R.id.ForumImageView);
                this.PostListener = f_listener;
                itemView.setOnClickListener(this);


            }




            @Override
            public void onClick(View v) {
                PostListener.onPostClick(getAdapterPosition());
            }

            public interface OnPostClick{
                public void onPostClick(int index);

            }

        }


}
