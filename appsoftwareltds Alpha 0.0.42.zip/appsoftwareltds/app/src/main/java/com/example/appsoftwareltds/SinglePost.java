package com.example.appsoftwareltds;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;


import java.util.ArrayList;
import java.util.HashMap;

public class SinglePost extends AppCompatActivity {

    private ImageView singlePostImg;
    private TextView PostTitle, PostDescription;
    private EditText AddComment;
    private Button AddCommentBtn, BackBtn;
    private ArrayList<ModelComment> CommentList;
    private MyCommentAdapter CommentAdapter;
    ModelForum Forum;
    RecyclerView RECComment;
    FirebaseAuth mAuth;
    DatabaseReference CommentRoot;
    FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    private DatabaseReference root = firebaseDatabase.getReference().child("Forum_Comments");
    DatabaseReference databaseReference;
    private String PostID;

        //this activity will be presented to the user when he clicks on an individual post in 'Forum' activity

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_post);
        mAuth = FirebaseAuth.getInstance();
        Forum = getIntent().getParcelableExtra("post");


        BackBtn = findViewById(R.id.BackButton3);
        BackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SinglePost.this, Forum.class));
            }
        });

        RECComment = findViewById(R.id.comment_recycler);
        RECComment.setHasFixedSize(false);
        RECComment.setLayoutManager(new LinearLayoutManager(this));

        CommentList = new ArrayList<>();
        CommentAdapter = new MyCommentAdapter(this, CommentList);

        RECComment.setAdapter(CommentAdapter);


        PostTitle = findViewById(R.id.post_view_title);
        PostDescription = findViewById(R.id.post_view_description);
        AddComment = findViewById(R.id.post_add_comment);
        AddCommentBtn = findViewById(R.id.comment_button);

        PostID = Forum.getPost_ID();
        PostTitle.setText(Forum.getTitle());
        PostDescription.setText(Forum.getDescription());


        singlePostImg = findViewById(R.id.post_view_img);


        Picasso.get().load(Forum.getImage_ID()).fit().into(singlePostImg);









        AddCommentBtn.setOnClickListener(new View.OnClickListener() {        // comment posting button
            @Override
            public void onClick(View v) {
                FirebaseDatabase ForumData = FirebaseDatabase.getInstance();
                CommentRoot = ForumData.getReference().child("Forum_Comments");



                String UserComment = AddComment.getText().toString();



                databaseReference = firebaseDatabase.getReference("User_Data").child("Details");

                // posting a comment and saving it's data in the database is handled by this
                Query UserNameQuery = databaseReference.orderByChild("ID").equalTo(mAuth.getCurrentUser().getUid());
                UserNameQuery.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                            String Name = " " + dataSnapshot1.child("First_Name").getValue() + " " + dataSnapshot1.child("Last_Name").getValue();


                            HashMap<String, String> PostMap = new HashMap<>();

                            PostMap.put("UserID", mAuth.getCurrentUser().getUid());
                            PostMap.put("Comment", UserComment);
                            PostMap.put("PostID", PostID);
                            PostMap.put("UserName", Name);
 

                            CommentRoot.push().setValue(PostMap);

                            Toast.makeText(SinglePost.this, "Comment Posted", Toast.LENGTH_LONG).show();

                            AddComment.setText(""); // the text in the edit text view will be reset

                            CommentAdapter.notifyDataSetChanged();


                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });


            }
        });








        Query Comment_ID_Query = root.orderByChild("PostID").equalTo(PostID); // this will display comments under each post that are also SPECIFIC to that post
        Comment_ID_Query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {

                        ModelComment model = dataSnapshot.getValue(ModelComment.class);
                        CommentList.add(model);

                    CommentAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });






















    }
}