package com.example.appsoftwareltds;

import android.os.Parcel;
import android.os.Parcelable;

public class ModelForum implements Parcelable {

    String Title;
    String Description;
    String Image_ID;
    String Post_ID; // these strings need be written exactly as they are in the database in order to be displayed in the home activity's recycler view

    public ModelForum(){}

    protected ModelForum(Parcel in) {

        Description = in.readString();

        Image_ID = in.readString();

        Title = in.readString();

        Post_ID = in.readString();

    }

    public static final Creator<ModelForum> CREATOR = new Creator<ModelForum>() {
        @Override
        public ModelForum createFromParcel(Parcel in) {
            return new ModelForum(in);
        }

        @Override
        public ModelForum[] newArray(int size) {
            return new ModelForum[size];
        }
    };

    public String getPost_ID() {
        return Post_ID;
    }

    public void setPost_ID(String post_ID) {
        Post_ID = post_ID;
    }


    public String getTitle() {
        return  Title;
    }

    public String getDescription() {
        return  Description;
    }


    public String getImage_ID() {
        return Image_ID;
    }

    @Override
    public int describeContents() {
        return 0;
    }


    @Override
    public void writeToParcel(Parcel dest, int flags) {

        dest.writeString(Description);

        dest.writeString(Image_ID);

        dest.writeString(Title);

        dest.writeString(Post_ID);

    }


}
