package com.example.appsoftwareltds;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.annotations.NotNull;
import com.google.firebase.storage.StorageReference;

import java.util.HashMap;


public class RegisterActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    TextView alreadyHaveaccount;
    EditText inputFn, inputLn, inputEmail, inputPassword, inputConfirmPassword,inputLoc;
    Spinner register_spinner;

    Button btnRegister;
    ProgressDialog progressDialog;

    FirebaseAuth mAuth; //FOR USER DETAILS
    private FirebaseDatabase UData = FirebaseDatabase.getInstance();
    private DatabaseReference root = UData.getReference().child("User_Data").child("Details"); //USER DATA

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);




        alreadyHaveaccount = findViewById(R.id.alreadyHaveaccount);


        register_spinner = findViewById(R.id.register_spinner); //account type spinner
        ArrayAdapter adapter = ArrayAdapter.createFromResource(RegisterActivity.this,R.array.groups, android.R.layout.simple_spinner_item);
        register_spinner.setAdapter(adapter);
        register_spinner.setOnItemSelectedListener(this); //spinner end

        inputFn = (findViewById(R.id.inputFn));
        inputLn = (findViewById(R.id.inputLn));
        inputEmail = (findViewById(R.id.inputEmail));
        inputPassword = (findViewById(R.id.inputPassword));
        inputLoc = (findViewById(R.id.inputUserAddress));
        inputConfirmPassword = (findViewById(R.id.inputConfirmPassword));




        btnRegister = (findViewById(R.id.btnRegister));
        progressDialog = new ProgressDialog(this);
        mAuth = FirebaseAuth.getInstance();
        mAuth.signOut();




        alreadyHaveaccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegisterActivity.this, MainActivity.class));
            }
        });


        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //registration class
                 
                if (!TextUtils.isEmpty(inputEmail.getText().toString()) &&
                        !TextUtils.isEmpty(inputPassword.getText().toString()) && inputPassword.getText().toString().compareTo(inputConfirmPassword.getText().toString()) == 0
                        && inputPassword.getText().toString().length() >= 6) {





                    mAuth.createUserWithEmailAndPassword(inputEmail.getText().toString(),
                            inputPassword.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull @NotNull Task<AuthResult> task) {
                            progressDialog.dismiss();
                            sendUserToNextActivity();
                            Toast.makeText(RegisterActivity.this, "Registration Successful", Toast.LENGTH_LONG).show();

                            //saving USER DATA start ---------------------------------------------
                            String UMail = inputEmail.getText().toString();
                            String FName = inputFn.getText().toString();
                            String LName = inputLn.getText().toString();
                            String AType = register_spinner.getSelectedItem().toString();
                            String Loc = inputLoc.getText().toString();


                            HashMap<String , String> DetailsMap = new HashMap<>();

                            DetailsMap.put("ID" , mAuth.getCurrentUser().getUid());

                            DetailsMap.put("Email" , UMail);
                            DetailsMap.put("First_Name" , FName);
                            DetailsMap.put("Last_Name" , LName);
                            DetailsMap.put("Account_Type" , AType);
                            DetailsMap.put("Address" , Loc);


                            root.push().setValue(DetailsMap);

                            //User information will be stored in firebase while also creating a new account
                            //saving USER DATA end ---------------------------------------------


                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull @NotNull Exception e) {
                            progressDialog.dismiss();
                            Toast.makeText(RegisterActivity.this, "Something is not right. Try Again.", Toast.LENGTH_LONG).show();

                        }


                        });
                        } else { Toast.makeText(RegisterActivity.this, "Incorrect Fields", Toast.LENGTH_SHORT).show();
                    Toast.makeText(RegisterActivity.this, "Password should be over 6 characters", Toast.LENGTH_LONG).show();}
        }
        });
    } //registration end



            private void sendUserToNextActivity() {
                Intent intent=new Intent(RegisterActivity.this,MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        }