package com.example.appsoftwareltds;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Query;

import android.widget.ImageView;
import java.util.ArrayList;


public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {



    ArrayList<ModelRoom> mList;
    Context context;
    MyViewHolder.OnPropertyClick listener;





    public MyAdapter (Context context, ArrayList<ModelRoom> mList, MyViewHolder.OnPropertyClick _listener){
        this.mList = mList;
        this.context = context;
        listener = _listener;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.room_card, parent, false);
        return new MyViewHolder(v, listener);


    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {



        ModelRoom model = mList.get(position);
        String image = mList.get(position).getImage_ID();
        holder.Title.setText(model.getTitle());
        holder.Type.setText(model.getType());
        holder.Price.setText(model.getPrice());
        holder.Address.setText(model.getAddress());
        holder.Telephone.setText(model.getTelephone());
        holder.Number_of_Rooms.setText(model.getNumber_of_Rooms());
        holder.Facilities.setText(model.getFacilities());
        holder.Description.setText(model.getDescription());
        holder.available_date.setText(model.getAvailable_Date());
        holder.picture.setVisibility(View.VISIBLE);
        try {
            Glide.with(context).load(image).into(holder.picture);
        } catch (Exception e) {}


    }

    @Override
    public int getItemCount() {
        return mList.size();
    }



    public static class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {





        ImageView picture;
        TextView Title, Type, Price, Address, Telephone, Number_of_Rooms, Facilities, Description,available_date;
        OnPropertyClick listener;

        public MyViewHolder(@NonNull View itemView, OnPropertyClick _listener) {
            super(itemView);

            Title = itemView.findViewById(R.id.title_display);
            Type  = itemView.findViewById(R.id.Posted_display);
            Price  = itemView.findViewById(R.id.Price_display);
            Address  = itemView.findViewById(R.id.Location_display);
            picture = itemView.findViewById(R.id.RoomImageView);
            Telephone = itemView.findViewById(R.id.Tel_display);
            Number_of_Rooms = itemView.findViewById(R.id.RoomNo_display);
            Facilities = itemView.findViewById(R.id.Facilities_display);
            Description = itemView.findViewById(R.id.Description_display);
            available_date = itemView.findViewById(R.id.Available_display);
            this.listener = _listener;
            itemView.setOnClickListener(this);


        }

        @Override
        public void onClick(View v) {
            listener.onPropertyClick(getAdapterPosition());
        }

        public interface OnPropertyClick{
            public void onPropertyClick(int index);

        }


    }

}
