package com.example.appsoftwareltds;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.database.Query;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.auth.FirebaseUser;

import java.util.ArrayList;

public class ViewMyListings extends AppCompatActivity implements  MyAdapter.MyViewHolder.OnPropertyClick {

    private Button Back;
    private RecyclerView recyclerView;
    FirebaseUser currentUser ;

    FirebaseAuth mAuth;
    FirebaseDatabase db = FirebaseDatabase.getInstance();
    private DatabaseReference root = db.getReference().child("User_Properties").child("Posted_Properties");
    private MyAdapter adapter;
    private ArrayList<ModelRoom> list;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_my_listings);


        Back = findViewById(R.id.BackButton1);
        Back.setOnClickListener(new View.OnClickListener() {     // The back button will take the user back to home activity
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ViewMyListings.this, HomeActivity.class));
            }
        });



        recyclerView = findViewById(R.id.MyListingsRecycler);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        list = new ArrayList<>();

        adapter = new MyAdapter(this, list ,ViewMyListings.this);

        recyclerView.setAdapter(adapter);

        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();

       Query query = root.orderByChild("UserID").equalTo(currentUser.getUid()); // This query will make sure that only properties that share the user id will be shown
        query.addValueEventListener(new ValueEventListener() {              //thus the user will only view rooms posted by him
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                    ModelRoom model = dataSnapshot.getValue(ModelRoom.class);
                    list.add(model);
                //    Toast.makeText(ViewMyListings.this, model.getAvailable(), Toast.LENGTH_LONG).show();
                }
                adapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();
    }

    @Override
    public void onPropertyClick(int index) {
        Intent intentRoom = new Intent(ViewMyListings.this, SingleRoom.class);
        intentRoom.putExtra("property", list.get(index));
        intentRoom.putExtra("Availability", true);
        startActivity(intentRoom);
    }


}