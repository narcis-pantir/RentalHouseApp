
package com.example.appsoftwareltds;


public class ModelUser {
    String First_Name,Last_Name,Account_Type,Address,Image,ID; // these strings need be written exactly as they are in the database in order to be displayed in the home activity's recycler view

    public String getID() {
        return  ID;
    }

    public String getFirst_Name() {
        return  First_Name;
    }

    public String getLast_Name() {
        return  Last_Name;
    }

    public String getAccount_Type() {
        return "Type of User: " + Account_Type;
    }

    public String getAddress() {
        return "Address: " + Address;
    }



}
